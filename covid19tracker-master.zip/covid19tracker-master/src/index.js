import React from 'react';
import ReactDOM from 'react-dom';

import Apps from "./App";

ReactDOM.render(<Apps/>,document.getElementById('root'));